
$(document).ready(function() {
$('.activate_grieva').show();
$('#chatbot').hide();

$('.activate_grieva').click(function(event) {
event.preventDefault();
$('#chatbot').show();
$('.activate_grieva').hide();
});

$('#grieva-exit').click(function(event) {
event.preventDefault();
$('.activate_grieva').show();
$('#chatbot').hide();
})
});


