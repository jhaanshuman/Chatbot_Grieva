var username = "";
function send_message(init_bot){
var  grieva_init = init_bot;

	var finalTime = new Date();
var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun","Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
	var year = finalTime.getFullYear();
	var month = finalTime.getMonth()+1 ;
	var monthName = monthNames[finalTime.getMonth()]
	var date = finalTime.getDate();
	var hour = finalTime.getHours()>12 ? finalTime.getHours()-12 : finalTime.getHours();
	var meridian = hour>12 ? "AM" : "PM";
	var minute = finalTime.getMinutes();
	var seconds = finalTime.getSeconds();
	var dateTime = "<hr>" +  "<div id='Btime'>" + date + "th " + monthName + " " + year + " " + hour +  ":" + minute + ":" + seconds + " " + meridian + "</div>";

var botname = "<span class='bot_name'>Grieva: </span>";
var botInitText = "<span class='botText'> Hello," + username + " how may i help you ? </span>"
var botInitcontainer = "<div id='bot_container'>" + botInitText + dateTime + "</div>";

    $("#container").html(botInitcontainer);}
	function get_username(init_bot){send_message(" Hello, how may i help you ?");}
	function ai(NewInput){$("#container").html(prevState + NewInput + "<br>");}

$(function(){
	var finalTime = new Date();
var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun","Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
	var year = finalTime.getFullYear();
	var month = finalTime.getMonth()+1 ;
	var monthName = monthNames[finalTime.getMonth()]
	var date = finalTime.getDate();
	var hour = finalTime.getHours()>12 ? finalTime.getHours()-12 : finalTime.getHours();
	var meridian = hour>12 ? "AM" : "PM";
	var minute = finalTime.getMinutes();
	var seconds = finalTime.getSeconds();
	var UdateTime = "<hr>" +  "<div id='Utime'>" + date + "th " + monthName + " " + year + " " + hour + ":" + minute + ":" + seconds + " " + meridian + "</div>";
	var BdateTime = "<hr>" +  "<div id='Btime'>" + date + "th " + monthName + " " + year + " " + hour + ":" + minute + ":" + seconds + " " + meridian + "</div>";

    get_username();

	$("#textbox").keyup(function(event) { if (event.keyCode === 13) {$("#send").click(); } });

      $("#send").click(function(){
        var Input = $("#textbox").val();                        
        var NewInput = Input.toLowerCase().split(" ");
        var InputLen = Input.split(" ").length;
	//var dataBase = database.toLowercase();
	var dbLen = database.length;
	var query = new Array();
	var ans = new Array();
	var k = 0 ;
	var l=0;
	var alt="";

        $("#textbox").val("");
        var prevState = $("#container").html();
        if (prevState.length > 3){prevState = prevState + "";}  

	var userText = "<div class='userText'>" + Input + "</div>";
	var usercontainer = "<br><div id='user_container'>" + userText + UdateTime + "</div>";
	var br = "<br>";

        for(h=0;h<InputLen ;h++){
			for(i=0;i<dbLen;i++){
	   			 for(j=0;j<database[i].split(" ").length;j++){
					var p = NewInput[h];
					var q = database[i].toLowerCase().split(" ")[j];
        				if(p==q){
						alt = alt + " " + p;
						max = alt.split(" ").length
						if(max>k){k=max;}
					for(;l<100;){ans[l] = p; var ind = i; query[l]=i; break;
					}l++;
						b={}; var max='',maxi=0; for(let k of query){if(b[k])b[k]++; else b[k]=1;
						if(maxi<b[k]){max=k;maxi=b[k] }}
   	}    }     }    }
				
		
         
var QbotText = "<div class='botText'>" +"<strong>" + database[max] +"</strong>" + "</div>";
var AbotText = "<div class='botText'>" + answers[max] + " " + "<a href=" + link[max]+ ">" + link[max]+ "</a>"+ "</div>";
var botcontainer = "<div id='bot_container'>" +  QbotText+ "<hr>" + AbotText + BdateTime + "</div>";
	$("#container").html(prevState + usercontainer + br + botcontainer);
       	$("#container").scrollTop($("#container").height()+1500);
        ai(NewInput);
    	});
});
